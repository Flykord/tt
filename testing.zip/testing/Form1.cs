﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsInput;

namespace testing
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
        private Process externalProcess;
        public string currentProcess;
        public string mobisysProcessName = "MobisysClient100";
        
        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);


        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc enumProc, IntPtr lParam);
        
        [DllImport("user32.dll")]
        private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);


        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetForegroundWindow(IntPtr hWnd);
        
        [DllImport("User32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool SwitchToThisWindow(IntPtr hWnd, bool fAltTab);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr nWnd,int nCmdShow);
        [DllImport("user32.dll")]
        private static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int uMsg, IntPtr wParam, string lParam);
        const int WM_SETTEXT = 0x000C;
        public const int  WM_CLOSE = 0x0010;

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern string SendMessage(int hWnd, int msg, string wParam, IntPtr lParam);

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool PostThreadMessage(IntPtr threadId, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        public static extern uint GetCurrentThreadId();

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll")]
        public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();


        private const int SWP_NOSIZE = 0x0001;
        private const int SWP_NOMOVE = 0x0002;
        private const int SWP_SHOWWINDOW = 0x0040;
        public string prog;
        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        public static Process p= new Process();
        const int SW_RESTORE = 9;
        InputSimulator sim = new InputSimulator();
        public Form1()
        {
            InitializeComponent();
            getCurrentProcessName();
            //mobisysProcessName = "Notepad";
            //mobisysProcessName = "prodProject";
            //mobisysProcessName = "teams";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void openProgram(string progName)
        {
            externalProcess = Process.Start(progName);

            // Esperar a que la ventana del proceso externo se cargue completamente
            externalProcess.WaitForInputIdle();

            // Obtener el identificador de la ventana del proceso externo
            IntPtr externalWindowHandle = externalProcess.MainWindowHandle;

            // Superponer la ventana del proceso externo en este formulario
            if (externalWindowHandle != IntPtr.Zero)
            {
                SetParent(externalWindowHandle, this.Handle);
            }

            // Redimensionar y mover la ventana del proceso externo si es necesario
            // Esto depende de tus necesidades específicas

            // Liberar recursos cuando se cierre este formulario
            this.FormClosed += (s, e) =>
            {
                externalProcess.CloseMainWindow(); // Cierra el programa externo
                externalProcess.WaitForExit();
                externalProcess.Dispose();
            };
        }

        private string getWindowName()
        {
            string processName = "Teams"; // Por ejemplo, para Google Chrome
            string windowTitle;
            // Buscar el proceso por nombre
            Process[] processes = Process.GetProcessesByName(processName);
            Process[] allProcesses  = Process.GetProcesses();

            if (processes.Length > 0)
            {
                // Obtener el título de la ventana principal del primer proceso encontrado
                windowTitle = processes[0].MainWindowTitle;

                if (!string.IsNullOrEmpty(windowTitle))
                {
                    MessageBox.Show("Título de la ventana: " + windowTitle);
                    return windowTitle;
                }
                else
                {
                    MessageBox.Show("La ventana no tiene un título.");
                    return "";
                }
            }
            else
            {
                Console.WriteLine("La aplicación no está en ejecución.");
                return "";
            }
        }
        public void copyToClipboard()
        {
            if (textBox1.Text != string.Empty)
            {
                
                Clipboard.SetText(textBox1.Text);
                //SendKeys.SendWait("^(c)");
                
                
            }
            else
            {
                MessageBox.Show("Se debe introducir previamente el texto");
            }
        }

        public void pasteFromClipboard(string text)
        {
            SendKeys.SendWait("^V");
            //SendKeys.Flush();
        }

        public void getAllProcess()
        {
            Process[] processes = Process.GetProcesses();
            String proc="";
            foreach(Process p in processes)
            {
                if(p.ProcessName.Contains("M"))
                proc += "\n" + p.ProcessName;
                
            }
            MessageBox.Show(proc);
        }
        private void superposeProgram(string procName)
        {
            string processName = procName;
            
            // Buscar el proceso por nombre
            Process[] processes = Process.GetProcessesByName(processName);
            if (processes.Length > 0)
            {
                // Obtener el identificador de la ventana principal del primer proceso encontrado
                Process p = processes.FirstOrDefault();
                
                
                    IntPtr windowHandle = p.MainWindowHandle;
                    //MessageBox.Show(windowHandle.ToString()+" "+p.WorkingSet64);
                    
                    if (windowHandle != IntPtr.Zero)
                    {
                        // Traer la ventana al frente
                        SetForegroundWindow(windowHandle);
                        //MessageBox.Show("Debería");
                    }
                    else
                    {
                        //SetForegroundWindow(windowHandle);
                        MessageBox.Show($"La ventana principal de {processName} no se encontró.");
                    }
                    
                
            }
            else
            {
                
                MessageBox.Show($"{processName} no está en ejecución.");
            }
        }
    
        private void button1_Click(object sender, EventArgs e)
        {           
            string texto = textBox1.Text;
            copyToClipboard();
            SuperposePid(mobisysProcessName);
            //superposeProgram(mobisysProcessName);
            System.Threading.Thread.Sleep(1000);
            pasteFromClipboard(texto);
            System.Threading.Thread.Sleep(1000);
            
            getCurrentProcessName();

            if (currentProcess != string.Empty)
            {
                superposeProgram(currentProcess);
                textBox1.Focus();
                Thread.Sleep(1000);
                pasteFromClipboard(texto);
            }
            
            else MessageBox.Show("No sl programa");
        }

        private void getCurrentProcessName()
        {
            Process procesoActual = Process.GetCurrentProcess();
            // Obtener el nombre del proceso
            string nombreDelProceso = procesoActual.ProcessName;
            currentProcess = nombreDelProceso;
            //MessageBox.Show("Nombre del proceso actual: " + nombreDelProceso);

        }
        private void button2_Click(object sender, EventArgs e)
        {
            getCurrentProcessName();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            getAllProcess();
        }

        private void button4_Click(object sender, EventArgs e)
        {
          
            PasteToApplication(mobisysProcessName);
        }



        public static void PasteToApplication(string appName)
        {
            bool result ;
            Process[] ps = Process.GetProcessesByName(appName);
            Process mobisys = ps.FirstOrDefault();
            var proc = Process.GetProcessesByName(appName).FirstOrDefault();

            if (proc != null)
            {
                var handle = proc.MainWindowHandle;
                if (IsIconic(handle))
                {
                    ShowWindow(handle, SW_RESTORE);
                    
                }
                
                result = SetForegroundWindow(handle);
                if (!result)
                {
                    MessageBox.Show("No realizo la tarea con exito");
                }
                SendKeys.SendWait("^v");
            }
            else
            {
                MessageBox.Show("No se encontro el proceso especidicado");
            }
        }

        public void BringWindowToFront(string windowTitle)
        {
            IntPtr hWnd = FindWindow(null, windowTitle);

            if (hWnd != IntPtr.Zero)
            {
                SetForegroundWindow(hWnd);
            }
            else
            {
                Console.WriteLine($"No se encontró una ventana con el título '{windowTitle}'.");
            }
        }

        private void BringWindowToFrontByTitle(string windowTitle)
        {
            Process[] processes = Process.GetProcesses();

            foreach (Process process in processes)
            {
                IntPtr windowHandle = process.MainWindowHandle;

                if (windowHandle != IntPtr.Zero)
                {
                    string title = GetWindowTitle(windowHandle);
                    MessageBox.Show(title);
                    if (title == windowTitle)
                    {
                        SetForegroundWindow(windowHandle);
                        return; // Salir del bucle si se encuentra la ventana
                    }
                }
            }

            // Mostrar mensaje si no se encontró la ventana
            MessageBox.Show($"No se encontró una ventana con el título '{windowTitle}'.");
        }

        private string GetWindowTitle(IntPtr windowHandle)
        {
            const int nChars = 256;
            StringBuilder buffer = new StringBuilder(nChars);
            GetWindowText(windowHandle, buffer, nChars);
            return buffer.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            superTest();
        }

        public static void BringWindowToFront1(string windowTitle)
        {
            IntPtr hWnd = FindWindow(null, windowTitle);
            Process[] processes = Process.GetProcesses();
            /*foreach(Process p in  processes)
            {
                MessageBox.Show(p.MainWindowTitle+" "+p.ProcessName);

            }*/
            if (hWnd != IntPtr.Zero)
            {
                
                SetForegroundWindow(hWnd);
            }
            else
            {
                MessageBox.Show($"La ventana con el título '{windowTitle}' no se encontró.");
            }
        }

        public static void superTest()
        {
            string windowTitleToBringToFront = "MobisysClient100";
            BringWindowToFront1(windowTitleToBringToFront);
        }

        public static int GetProcessID(string processName)
        {
            int processID = -1; // Valor predeterminado en caso de que no se encuentre el proceso
            
            Process[] processes = Process.GetProcessesByName(processName);

            if (processes.Length > 0)
            {
                
                // Obtiene el PID del primer proceso con el nombre especificado
                processID = processes[0].Id;
                p = processes[0];
            }
            else
            {
                Console.WriteLine($"No se encontró el proceso con nombre '{processName}'.");
            }

            return processID;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string processNameToFind = "MobisysClient100"; // Reemplaza con el nombre del proceso que deseas encontrar
            int processID = GetProcessID(processNameToFind);
           
            if (processID != -1)
            {
                MessageBox.Show($"El PID del proceso '{processNameToFind}' es: {processID}");
            }
            else
            {
                MessageBox.Show("No se pudo obtener el PID del proceso.");
            }
        }

        public  void BringWindowToFrontByPID(int targetPID)
        {
            IntPtr targetWindowHandle = IntPtr.Zero;
            
            EnumWindows((hWnd, lParam) =>
            {
                int windowPID;
                GetWindowThreadProcessId(hWnd, out windowPID);

                if (windowPID == targetPID)
                {
                    targetWindowHandle = hWnd;
                    return false; // Detener la enumeración
                }

                return true; // Continuar enumerando
            }, IntPtr.Zero);
            //MessageBox.Show(targetWindowHandle.ToString());
            if (targetWindowHandle != IntPtr.Zero)
            {

                //SetForegroundWindow(targetWindowHandle);

                //PostThreadMessage(targetWindowHandle,WM_SETTEXT,IntPtr.Zero,IntPtr.Zero);
                //SwitchWindow(targetWindowHandle);
                //pasteFromClipboard("rs");
                SwitchToThisWindow(targetWindowHandle, true);
                //r=SendMessage(targetWindowHandle,WM_SETTEXT,IntPtr.Zero,"-");
                //Console.WriteLine(r);
                //--
                
            }
            else
            {
               MessageBox.Show($"No se encontró ninguna ventana para el proceso con PID {targetPID}.");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            copyToClipboard();
            SuperposePid(mobisysProcessName);
            Thread.Sleep(5000);
            // SendKeys.SendWait("^(v)");
            //sim.Keyboard.Sleep(500);
            //sim.Keyboard.TextEntry("ggdhskhl");
            pasteFromClipboard("-----");
            Thread.Sleep(2000);
            //pasteFromClipboard("-----");
            
        }

        private void SuperposePid(string procName)
        {
            int targetProcessPID = -1;
            targetProcessPID = GetProcessID(mobisysProcessName);
            if (targetProcessPID != -1)
            {
                //MessageBox.Show(targetProcessPID.ToString());
                
                BringWindowToFrontByPID(targetProcessPID);
                //PostThreadMessage(targetProcessPID,WM_SETTEXT,IntPtr.Zero,IntPtr.Zero);
            }
            else
            {
                MessageBox.Show("The app cant get the PID");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            PasteToApplication(mobisysProcessName);
        }

        private void superposeWin(string name)
        {
            Process[] processes = Process.GetProcessesByName(name);
            if (processes.Any()) 
            {
                IntPtr hWnd = processes[0].MainWindowHandle;
                
                if(IsIconic(hWnd))
                {
                    ShowWindow(hWnd, 1);
                }
                else
                {
                    SetForegroundWindow(hWnd);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            superposeWin(mobisysProcessName);
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        public static void SwitchWindow(IntPtr windowHandle)
        {
            if (GetForegroundWindow() == windowHandle)
                return;

            IntPtr foregroundWindowHandle = GetForegroundWindow();
            uint currentThreadId = GetCurrentThreadId();
            uint temp;
            uint foregroundThreadId = GetWindowThreadProcessId(foregroundWindowHandle, out temp);
            AttachThreadInput(currentThreadId, foregroundThreadId, true);
            SetForegroundWindow(windowHandle);
            AttachThreadInput(currentThreadId, foregroundThreadId, false);

            while (GetForegroundWindow() != windowHandle)
            {
            }
        }

        /*private void newMethodToTry()
        {
            var notepad = System.Diagnostics.Process.GetProcessesByName(&#34;notepad&#34;).FirstOrDefault();
            if (notepad != null)
            {
                var root = AutomationElement.FromHandle(notepad.MainWindowHandle);
                var element = root.FindAll(TreeScope.Subtree, Condition.TrueCondition)
                    .Cast & lt; AutomationElement & gt; ()
                    .Where(x = &gt; x.Current.ClassName == &#34;Edit&#34; &amp;&amp;
            x.Current.AutomationId == &#34;15&#34;).FirstOrDefault();
            if (element != null)
                {
                    if (element.TryGetCurrentPattern(ValuePattern.Pattern, out object pattern))
                    {
                        ((ValuePattern)pattern).SetValue(&#34;This is a test.&#34;);
            }
                    else
                    {
                        element.SetFocus();
                        SendKeys.SendWait(&#34;^{HOME}&#34;);   // Move to start of control
            SendKeys.SendWait(&#34;^+{END}&#34;);   // Select everything
            SendKeys.SendWait(&#34;{DEL}&#34;);     // Delete selection
            SendKeys.SendWait(&#34;This is a test.&#34;);
           // OR 
           // SendMessage(element.Current.NativeWindowHandle, WM_SETTEXT, 0, &#34;This is a test.&#34;);
        }
                }
            }
        }*/


    }
}

